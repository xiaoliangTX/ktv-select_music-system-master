<template>
    <div class="Index">
    </div>
</template>
<script>
export default {
    name:"Index",
    data(){
        return{
            
        }
    },
}
</script>
<style lang="less" scoped>
.Index{
    width: 100%;
    height: 100%;
    padding: 30px 20px;
    background-image: url(../assets/image/info-bg.jpg);
    background-size: 100% 100%;
}
</style>